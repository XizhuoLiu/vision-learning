import cv2
import matplotlib.pyplot as plt

# 加载两张图像（替换路径为你解压的实际位置）
img1 = cv2.imread("vo_synthetic_frames/frame_000.jpg", cv2.IMREAD_GRAYSCALE)
img2 = cv2.imread("vo_synthetic_frames/frame_001.jpg", cv2.IMREAD_GRAYSCALE)

# 创建 ORB 特征提取器
orb = cv2.ORB_create(nfeatures=500)

# 提取关键点和描述子
kp1, des1 = orb.detectAndCompute(img1, None)
kp2, des2 = orb.detectAndCompute(img2, None)

# 使用暴力匹配器进行特征匹配
bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)
matches = bf.match(des1, des2)
matches = sorted(matches, key=lambda x: x.distance)

# 可视化前 50 个匹配结果
img_match = cv2.drawMatches(img1, kp1, img2, kp2, matches[:50], None, flags=2)

plt.figure(figsize=(12, 6))
plt.imshow(img_match, cmap="gray")
plt.title("ORB Feature Matches")
plt.axis("off")
plt.show()

import numpy as np

# 相机内参矩阵（合成图像中使用的）
K = np.array([[800, 0, 320],
              [0, 800, 240],
              [0,   0,   1]])

# 提取匹配点的像素坐标
pts1 = np.float32([kp1[m.queryIdx].pt for m in matches]).reshape(-1, 1, 2)
pts2 = np.float32([kp2[m.trainIdx].pt for m in matches]).reshape(-1, 1, 2)

# 估计本质矩阵
E, _ = cv2.findEssentialMat(pts1, pts2, K, method=cv2.RANSAC, prob=0.999, threshold=1.0)

# 恢复相对位姿 R, t
_, R, t, _ = cv2.recoverPose(E, pts1, pts2, K)

# 打印 R 和 t
print("🔁 相对旋转矩阵 R:\n", R)
print("📍 相对平移向量 t:\n", t)