
import numpy as np
import cv2
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

# 1. 加载 3D 点（立方体）
object_points = np.loadtxt("object_points3d.txt")

# 2. 加载 PnP 结果中的 rvec 和 tvec
# 你可以从 pnp_pose_estimation.py 输出中复制实际值到这里
# 示例：
rvec = np.array([[0.3], [0.2], [0.1]])  # 可替换成你自己的
tvec = np.array([[0.5], [0.5], [4.0]])  # 可替换成你自己的

# 3. 转换旋转向量为旋转矩阵
R, _ = cv2.Rodrigues(rvec)

# 4. 计算相机在世界坐标下的位置（相机坐标原点在世界坐标中的位置）
camera_position = -R.T @ tvec

# 5. 创建图形
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
ax.set_title("Camera Pose Visualization")

# 6. 绘制立方体点
ax.scatter(object_points[:, 0], object_points[:, 1], object_points[:, 2], c='b', label='3D Points')

# 7. 绘制相机位置
ax.scatter(camera_position[0], camera_position[1], camera_position[2], c='r', label='Camera')

# 8. 绘制相机坐标系方向（x:红，y:绿，z:蓝）
axis_length = 0.5
cam_origin = camera_position.ravel()
x_axis = cam_origin + R.T @ np.array([axis_length, 0, 0])
y_axis = cam_origin + R.T @ np.array([0, axis_length, 0])
z_axis = cam_origin + R.T @ np.array([0, 0, axis_length])

ax.plot([cam_origin[0], x_axis[0]], [cam_origin[1], x_axis[1]], [cam_origin[2], x_axis[2]], c='r')
ax.plot([cam_origin[0], y_axis[0]], [cam_origin[1], y_axis[1]], [cam_origin[2], y_axis[2]], c='g')
ax.plot([cam_origin[0], z_axis[0]], [cam_origin[1], z_axis[1]], [cam_origin[2], z_axis[2]], c='b')

# 9. 设置坐标轴
ax.set_xlabel("X")
ax.set_ylabel("Y")
ax.set_zlabel("Z")
ax.legend()
ax.set_box_aspect([1, 1, 1])
plt.tight_layout()
plt.show()
