
import cv2
import numpy as np

# 1. 加载3D点和2D点
object_points = np.loadtxt("object_points3d.txt")  # shape: (8, 3)
image_points = np.loadtxt("image_points2d.txt")    # shape: (8, 2)

# 2. 构建相机内参矩阵
fx, fy = 800, 800
cx, cy = 320, 240
camera_matrix = np.array([
    [fx, 0, cx],
    [0, fy, cy],
    [0,  0,  1]
], dtype=np.float64)

# 3. 使用 solvePnP 求解位姿
success, rvec, tvec = cv2.solvePnP(object_points, image_points, camera_matrix, None)

# 4. 输出结果
if success:
    print("✔️ 成功估计相机位姿:")
    print("Rotation Vector (rvec):\n", rvec)
    print("Translation Vector (tvec):\n", tvec)
else:
    print("❌ 位姿估计失败")

# 5. 可选：将旋转向量转换为旋转矩阵
R, _ = cv2.Rodrigues(rvec)
print("Rotation Matrix (R):\n", R)

# 6. 可选：打印相机坐标系的位置
camera_position = -R.T @ tvec
print("Camera Position in World Coordinates:\n", camera_position.ravel())
