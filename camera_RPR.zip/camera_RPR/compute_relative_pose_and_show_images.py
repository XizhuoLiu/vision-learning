
import numpy as np
import cv2
import matplotlib.pyplot as plt

# 加载图像
ref_img = cv2.imread("ref_image.jpg")
query_img = cv2.imread("query_image.jpg")

# 加载位姿（旋转向量和位移）
rvec1 = np.loadtxt("rvec1.txt").reshape(3, 1)
tvec1 = np.loadtxt("tvec1.txt").reshape(3, 1)
rvec2 = np.loadtxt("rvec2.txt").reshape(3, 1)
tvec2 = np.loadtxt("tvec2.txt").reshape(3, 1)

# 将旋转向量转换为旋转矩阵
R1, _ = cv2.Rodrigues(rvec1)
R2, _ = cv2.Rodrigues(rvec2)

# 相对旋转和平移（从 ref 到 query）
R_rel = R2 @ R1.T
t_rel = tvec2 - R_rel @ tvec1

# 将相对旋转矩阵转为旋转向量
rvec_rel, _ = cv2.Rodrigues(R_rel)

print("📐 相对旋转向量 (rvec_rel):\n", rvec_rel)
print("📍 相对平移向量 (tvec_rel):\n", t_rel)

# 显示图像对
fig, axs = plt.subplots(1, 2, figsize=(12, 5))
axs[0].imshow(cv2.cvtColor(ref_img, cv2.COLOR_BGR2RGB))
axs[0].set_title("Reference Image")
axs[0].axis("off")

axs[1].imshow(cv2.cvtColor(query_img, cv2.COLOR_BGR2RGB))
axs[1].set_title("Query Image")
axs[1].axis("off")

plt.tight_layout()
plt.show()
